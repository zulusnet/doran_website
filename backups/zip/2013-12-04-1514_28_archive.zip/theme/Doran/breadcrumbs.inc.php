<?php if(!defined('IN_GS')){ die('you cannot load this page directly.'); } 
/****************************************************
*
* @File:        breadcrumbs.inc.php
* @Package:     Doran - Technologie OZE
* @Action:      Szablon wykonany dla firmy Doran, 2013
*
*****************************************************/
?>
<div class="breadcrumbs">
    
	<?php
	/*
    <div class="container">
        <span class="home">
            <i class="fa fa-home fa-lg"></i>
        </span>
        <?php get_i18n_breadcrumbs(return_page_slug()); ?>
    </div>
	*/
	?>
    
</div>