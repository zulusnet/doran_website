<?php if(!defined('IN_GS')){ die('you cannot load this page directly.'); } 
/****************************************************
*
* @File:        breadcrumbs.inc.php
* @Package:     Doran - Technologie OZE
* @Action:      Szablon wykonany dla firmy Doran, 2013
*
*****************************************************/
?>
<div class="breadcrumbs">
    
    <div class="container">
        <a href="<?php echo find_url('index', null); ?>"><i class="fa fa-home"></i></a>
        <?php get_i18n_breadcrumbs(return_page_slug()); ?>
    </div>
    
</div>